export  interface Movie {
  _id: string;
  title: string;
  description: string;
  genre: string[];
  duration: number;
  releaseDate: string;
  poster: string;
  rating: number;
  showtimes?: string[];
}

export interface Booking {
  _id: string;
  movieId: string;
  userId: string;
  showtime: string;
  seats: string[];
  totalPrice: number;
  bookingDate: string;
}
 