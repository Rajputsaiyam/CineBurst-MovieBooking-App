import  { Link } from 'react-router-dom';
import { MapPin } from 'lucide-react';

const TheatreCard = ({ theatre }) => {
  return (
    <div className="card group hover:shadow-xl transition-shadow">
      <Link to={`/theatres/${theatre._id}`} className="block relative overflow-hidden aspect-video">
        <img 
          src="https://images.unsplash.com/photo-1526041092449-209d556f7a32?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwzfHxtb3ZpZSUyMHRoZWF0ZXIlMjBjaW5lbWF8ZW58MHx8fHwxNzQ3MDM2MzU2fDA&ixlib=rb-4.1.0&fit=crop&w=600&h=337" 
          alt={theatre.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
      </Link>
      
      <div className="p-4">
        <Link to={`/theatres/${theatre._id}`} className="block">
          <h3 className="text-lg font-semibold mb-2 hover:text-primary-600 dark:hover:text-primary-500 transition-colors">
            {theatre.name}
          </h3>
        </Link>
        
        <div className="flex items-start text-sm text-gray-600 dark:text-gray-400 mb-4">
          <MapPin className="h-4 w-4 mr-1 mt-0.5 shrink-0" />
          <span>
            {theatre.plot}, {theatre.street}, {theatre.city}, {theatre.country}, {theatre.pincode}
          </span>
        </div>
        
        <Link 
          to={`/theatres/${theatre._id}`} 
          className="btn btn-primary w-full text-center"
        >
          View Shows
        </Link>
      </div>
    </div>
  );
};

export default TheatreCard;
 