import  { Link } from 'react-router-dom';
import { Clock, Star, Calendar } from 'lucide-react';
import { Movie } from '../types';

interface MovieCardProps {
  movie: Movie;
}

const MovieCard = ({ movie }: MovieCardProps) => {
  return (
    <div className="card group h-full flex flex-col transition-transform duration-300 hover:-translate-y-1 hover:shadow-lg">
      <div className="relative overflow-hidden">
        <img 
          src={movie.poster || 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=500&h=750&fit=crop'} 
          alt={movie.title} 
          className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-105"
        />
        <div className="absolute top-2 right-2 bg-primary-600 text-white py-1 px-2 rounded-md text-sm font-medium flex items-center">
          <Star className="h-4 w-4 mr-1 text-yellow-300" /> 
          {movie.rating}/10
        </div>
      </div>
      <div className="p-4 flex-grow flex flex-col">
        <h3 className="font-bold text-lg mb-2 line-clamp-1">{movie.title}</h3>
        <p className="text-gray-600 dark:text-gray-400 text-sm mb-3 line-clamp-2">{movie.description}</p>
        <div className="mt-auto">
          <div className="flex text-sm text-gray-500 dark:text-gray-400 mb-3 space-x-4">
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-1" />
              {movie.duration} min
            </div>
            <div className="flex items-center">
              <Calendar className="h-4 w-4 mr-1" />
              {new Date(movie.releaseDate).getFullYear()}
            </div>
          </div>
          <Link to={`/movies/${movie._id}`} className="btn btn-primary w-full text-center">
            Book Tickets
          </Link>
        </div>
      </div>
    </div>
  );
};

export default MovieCard;
 