import  { Link } from 'react-router-dom';
import { Clock, Calendar, Star } from 'lucide-react';

const MovieCard = ({ movie }) => {
  // Format release date
  const formatReleaseDate = (dateString) => {
    if (!dateString) return 'Coming Soon';
    return new Date(dateString).toLocaleDateString();
  };
  
  // Add genre array if not present
  const genres = movie.genre || ['Drama']; // Default genre if none provided
  
  return (
    <div className="card group hover:shadow-xl transition-shadow">
      <Link to={`/movies/${movie._id}`} className="block relative overflow-hidden aspect-[2/3]">
        <img 
          src={movie.coverImageURL || movie.poster || 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwyfHxtb3ZpZSUyMHRoZWF0ZXIlMjBjaW5lbWF8ZW58MHx8fHwxNzQ3MDM2MzU2fDA&ixlib=rb-4.1.0&fit=crop&w=500&h=750'} 
          alt={movie.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-2 left-2">
          <div className="flex items-center bg-white/90 dark:bg-dark-900/90 px-2 py-1 rounded-md">
            <Star className="h-4 w-4 text-yellow-500 mr-1" />
            <span className="text-sm font-medium">{movie.rating || '8.5'}</span>
          </div>
        </div>
      </Link>
      
      <div className="p-4">
        <Link to={`/movies/${movie._id}`} className="block">
          <h3 className="text-lg font-semibold mb-2 hover:text-primary-600 dark:hover:text-primary-500 transition-colors">
            {movie.title}
          </h3>
        </Link>
        
        <div className="flex flex-wrap items-center text-xs text-gray-600 dark:text-gray-400 mb-2 gap-x-4 gap-y-1">
          <div className="flex items-center">
            <Clock className="h-3 w-3 mr-1" />
            <span>{movie.duration || '120 min'}</span>
          </div>
          <div className="flex items-center">
            <Calendar className="h-3 w-3 mr-1" />
            <span>{formatReleaseDate(movie.releaseDate)}</span>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-1 mb-3">
          {genres.map(genre => (
            <span 
              key={genre} 
              className="text-xs px-2 py-1 bg-gray-100 dark:bg-dark-700 rounded-full"
            >
              {genre}
            </span>
          ))}
        </div>
        
        <Link 
          to={`/movies/${movie._id}`} 
          className="btn btn-primary w-full text-center"
        >
          Book Now
        </Link>
      </div>
    </div>
  );
};

export default MovieCard;
 