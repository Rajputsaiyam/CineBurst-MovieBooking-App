import  { Link } from 'react-router-dom';

const HeroSection = () => {
  return (
    <div className="relative">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1478720568477-152d9b164e26?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxtb3ZpZSUyMHRoZWF0ZXIlMjBjaW5lbWF8ZW58MHx8fHwxNzQ3MDM2MzU2fDA&ixlib=rb-4.1.0&fit=fillmax&h=800&w=1200" 
          alt="Cinema" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-dark-900/90 to-dark-800/70"></div>
      </div>
      <div className="relative z-10 container mx-auto px-4 py-20 md:py-32">
        <div className="max-w-xl">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6 leading-tight">
            Experience Movies Like Never Before
          </h1>
          <p className="text-xl text-gray-300 mb-8">
            Book your tickets for the latest blockbusters and secure the best seats in the house.
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
            <Link to="/movies" className="btn btn-primary px-8 py-3 text-lg">
              Browse Movies
            </Link>
            <Link to="/signup" className="btn btn-outline border-white text-white hover:bg-white/10 px-8 py-3 text-lg">
              Create Account
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;
 