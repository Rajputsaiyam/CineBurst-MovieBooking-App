import  { useState, useEffect } from 'react';
import TheatreCard from './TheatreCard';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const FeaturedTheatres = () => {
  const [theatres, setTheatres] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchTheatres = async () => {
      try {
        setLoading(true);
        // Instead of calling API directly, use mock data for now
        setTheatres(mockTheatres);
        setLoading(false);
      } catch (err) {
        setTheatres(mockTheatres);
        setError('Failed to fetch theatres');
        console.error('Error fetching theatres:', err instanceof Error ? err.message : String(err));
        setLoading(false);
      }
    };

    fetchTheatres();
  }, []);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="flex justify-center items-center h-60">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }

  if (error && theatres.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="flex justify-center items-center h-60">
          <p className="text-red-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-16 bg-gray-50 dark:bg-dark-900">
      <div className="flex justify-between items-center mb-10">
        <h2 className="text-3xl font-bold">Popular Theatres</h2>
        <div className="flex space-x-2">
          <button className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-dark-800 dark:hover:bg-dark-700">
            <ChevronLeft className="h-6 w-6" />
          </button>
          <button className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-dark-800 dark:hover:bg-dark-700">
            <ChevronRight className="h-6 w-6" />
          </button>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {theatres.map((theatre) => (
          <TheatreCard key={theatre._id} theatre={theatre} />
        ))}
      </div>
      <div className="text-center mt-12">
        <a href="/theatres" className="btn btn-outline">
          View All Theatres
        </a>
      </div>
    </div>
  );
};

// Mock data for preview
const mockTheatres = [
  {
    _id: '1',
    name: 'Grand Cineplex',
    plot: '123',
    street: 'Main Street',
    city: 'New York',
    country: 'USA',
    pincode: 10001,
    lat: '40.7128',
    lon: '-74.0060',
  },
  {
    _id: '2',
    name: 'Stellar Multiplex',
    plot: '456',
    street: 'Broadway Avenue',
    city: 'Los Angeles',
    country: 'USA',
    pincode: 90001,
    lat: '34.0522',
    lon: '-118.2437',
  },
  {
    _id: '3',
    name: 'Royal Cinema',
    plot: '789',
    street: 'Oak Street',
    city: 'Chicago',
    country: 'USA',
    pincode: 60007,
    lat: '41.8781',
    lon: '-87.6298',
  },
];

export default FeaturedTheatres;
 