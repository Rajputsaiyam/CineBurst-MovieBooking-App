import  { Link } from 'react-router-dom';
import { Film, Facebook, Twitter, Instagram, Mail } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-dark-900 text-white">
      <div className="container mx-auto px-4 py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <Link to="/" className="flex items-center space-x-2">
              <Film className="h-8 w-8 text-primary-500" />
              <span className="text-xl font-bold text-white">CineBooker</span>
            </Link>
            <p className="mt-4 text-gray-400">Book your favorite movies with ease. Premium cinema experience at your fingertips.</p>
            <div className="mt-6 flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-primary-500">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary-500">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary-500">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-400 hover:text-primary-500">Home</Link></li>
              <li><Link to="/movies" className="text-gray-400 hover:text-primary-500">Movies</Link></li>
              <li><Link to="/about" className="text-gray-400 hover:text-primary-500">About Us</Link></li>
              <li><Link to="/contact" className="text-gray-400 hover:text-primary-500">Contact</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Help & Support</h3>
            <ul className="space-y-2">
              <li><Link to="/faq" className="text-gray-400 hover:text-primary-500">FAQ</Link></li>
              <li><Link to="/terms" className="text-gray-400 hover:text-primary-500">Terms of Service</Link></li>
              <li><Link to="/privacy" className="text-gray-400 hover:text-primary-500">Privacy Policy</Link></li>
              <li><Link to="/support" className="text-gray-400 hover:text-primary-500">Support Center</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <address className="not-italic text-gray-400">
              <p>123 Cinema Street</p>
              <p>Movie City, MC 12345</p>
              <div className="mt-4 flex items-center space-x-2">
                <Mail className="h-5 w-5 text-primary-500" />
                <a href="mailto:info@cinebooker.com" className="hover:text-primary-500">info@cinebooker.com</a>
              </div>
            </address>
          </div>
        </div>
        <div className="border-t border-gray-800 mt-10 pt-6 text-center text-gray-500">
          <p>© {new Date().getFullYear()} CineBooker. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
 