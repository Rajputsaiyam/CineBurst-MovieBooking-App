import  { useState } from 'react';

const SeatSelector = ({ availableSeats, onSelectSeats }) => {
  const [selectedSeats, setSelectedSeats] = useState([]);
  
  const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
  const seatsPerRow = 10;
  
  const toggleSeat = (seat) => {
    if (selectedSeats.includes(seat)) {
      setSelectedSeats(selectedSeats.filter(s => s !== seat));
    } else {
      setSelectedSeats([...selectedSeats, seat]);
    }
  };
  
  const handleConfirm = () => {
    onSelectSeats(selectedSeats);
  };
  
  const getSeatStatus = (seat) => {
    if (selectedSeats.includes(seat)) return 'selected';
    if (!availableSeats.includes(seat)) return 'occupied';
    return 'available';
  };
  
  return (
    <div className="seat-selector">
      <div className="py-6">
        <div className="mx-auto max-w-3xl">
          <div className="mb-6 text-center">
            <div className="mb-10 rounded-lg bg-gray-800 p-4 text-center">
              <div className="mx-auto w-2/3 rounded-lg bg-gray-900 py-4 text-white">SCREEN</div>
            </div>
            
            <div className="mb-6 grid grid-cols-10 gap-2">
              {rows.map(row => (
                Array.from({ length: seatsPerRow }, (_, i) => {
                  const seatNumber = `${row}${i+1}`;
                  const status = getSeatStatus(seatNumber);
                  
                  return (
                    <button
                      key={seatNumber}
                      className={`
                        h-8 w-8 rounded-t-lg text-xs font-medium transition-colors
                        ${status === 'available' ? 'bg-gray-200 hover:bg-primary-200 dark:bg-gray-700 dark:hover:bg-primary-700' : ''}
                        ${status === 'selected' ? 'bg-primary-600 text-white' : ''}
                        ${status === 'occupied' ? 'bg-gray-400 cursor-not-allowed dark:bg-gray-600' : ''}
                      `}
                      onClick={() => status !== 'occupied' && toggleSeat(seatNumber)}
                      disabled={status === 'occupied'}
                    >
                      {seatNumber}
                    </button>
                  );
                })
              ))}
            </div>
            
            <div className="mb-8 flex items-center justify-center space-x-8">
              <div className="flex items-center">
                <div className="mr-2 h-4 w-4 rounded-t-sm bg-gray-200 dark:bg-gray-700"></div>
                <span className="text-sm">Available</span>
              </div>
              <div className="flex items-center">
                <div className="mr-2 h-4 w-4 rounded-t-sm bg-primary-600"></div>
                <span className="text-sm">Selected</span>
              </div>
              <div className="flex items-center">
                <div className="mr-2 h-4 w-4 rounded-t-sm bg-gray-400 dark:bg-gray-600"></div>
                <span className="text-sm">Occupied</span>
              </div>
            </div>
            
            <div className="mt-8">
              <button 
                onClick={handleConfirm}
                disabled={selectedSeats.length === 0}
                className={`btn ${selectedSeats.length > 0 ? 'btn-primary' : 'btn-outline opacity-50 cursor-not-allowed'} w-full`}
              >
                {selectedSeats.length > 0 
                  ? `Continue with ${selectedSeats.length} seat${selectedSeats.length > 1 ? 's' : ''}`
                  : 'Select at least one seat'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SeatSelector;
 