import  axios from 'axios';
import { Movie } from '../types';

// Set your API base URL here
const API_URL = 'http://localhost:5000/api';

// Create axios instance without transformRequest
const api = axios.create({
  baseURL: API_URL,
  transformRequest: undefined
});

export const getMovies = async (page = 1, limit = 6) => {
  try {
    const response = await api.get(`/movies?page=${page}&limit=${limit}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching movies:', error);
    throw error;
  }
};

export const getMovieById = async (id: string) => {
  try {
    const response = await api.get(`/movies/${id}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching movie:', error);
    throw error;
  }
};

export const createMovie = async (movieData: Partial<Movie>) => {
  try {
    const response = await api.post('/movies', movieData);
    return response.data;
  } catch (error) {
    console.error('Error creating movie:', error);
    throw error;
  }
};

export const updateMovie = async (id: string, movieData: Partial<Movie>) => {
  try {
    const response = await api.patch(`/movies/${id}`, movieData);
    return response.data;
  } catch (error) {
    console.error('Error updating movie:', error);
    throw error;
  }
};

export const deleteMovie = async (id: string) => {
  try {
    const response = await api.delete(`/movies/${id}`);
    return response.data;
  } catch (error) {
    console.error('Error deleting movie:', error);
    throw error;
  }
};

export const createBooking = async (bookingData: {
  movieId: string;
  showtime: string;
  seats: string[];
}) => {
  try {
    const response = await api.post('/bookings', bookingData);
    return response.data;
  } catch (error) {
    console.error('Error creating booking:', error);
    throw error;
  }
};
 