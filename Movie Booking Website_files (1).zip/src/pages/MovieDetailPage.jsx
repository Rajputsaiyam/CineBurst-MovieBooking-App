import  { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import SeatSelector from '../components/SeatSelector';
import { Clock, Calendar, Star, Users, ChevronDown, CreditCard, Globe } from 'lucide-react';

const MovieDetailPage = () => {
  const { id } = useParams();
  const [movie, setMovie] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [selectedTheatre, setSelectedTheatre] = useState(null);
  const [showSeatSelector, setShowSeatSelector] = useState(false);
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [isBookingComplete, setIsBookingComplete] = useState(false);
  
  // Mock available showtimes
  const dates = ['2023-11-01', '2023-11-02', '2023-11-03', '2023-11-04', '2023-11-05'];
  const times = ['10:00 AM', '1:30 PM', '4:00 PM', '7:30 PM', '10:00 PM'];
  const theatres = [
    { id: '1', name: 'Grand Cineplex', price: 12 },
    { id: '2', name: 'Stellar Multiplex', price: 14 },
    { id: '3', name: 'Royal Cinema', price: 10 }
  ];
  
  // Mock available seats
  const allSeats = Array.from({ length: 8 }, (_, i) => 
    Array.from({ length: 10 }, (_, j) => `${String.fromCharCode(65 + i)}${j+1}`)
  ).flat();
  
  // Randomly make some seats unavailable for the demo
  const unavailableSeats = allSeats.filter(() => Math.random() > 0.7);
  const availableSeats = allSeats.filter(seat => !unavailableSeats.includes(seat));
  
  useEffect(() => {
    const fetchMovie = async () => {
      if (!id) return;
      
      try {
        setLoading(true);
        // Instead of calling API directly, use mock data for now
        const foundMovie = mockMovies.find(m => m._id === id);
        if (foundMovie) {
          setMovie(foundMovie);
        } else {
          setMovie(mockMovies[0]);
        }
        setLoading(false);
      } catch (err) {
        setMovie(mockMovies[0]);
        setError('Failed to fetch movie details');
        console.error('Error fetching movie details:', err instanceof Error ? err.message : String(err));
        setLoading(false);
      }
    };
    
    fetchMovie();
  }, [id]);
  
  const handleDateSelect = (date) => {
    setSelectedDate(date);
    setSelectedTime(null);
    setSelectedTheatre(null);
    setShowSeatSelector(false);
  };
  
  const handleTimeSelect = (time) => {
    setSelectedTime(time);
    setSelectedTheatre(null);
    setShowSeatSelector(false);
  };
  
  const handleTheatreSelect = (theatre) => {
    setSelectedTheatre(theatre);
    setShowSeatSelector(false);
  };
  
  const handleShowSeatSelector = () => {
    if (selectedDate && selectedTime && selectedTheatre) {
      setShowSeatSelector(true);
    }
  };
  
  const handleSelectSeats = (seats) => {
    setSelectedSeats(seats);
    setIsBookingComplete(true);
  };
  
  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="flex justify-center items-center h-60">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }
  
  if (error || !movie) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="flex justify-center items-center h-60">
          <p className="text-red-600">{error || 'Movie not found'}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-8">
        <Link to="/movies" className="text-primary-600 hover:text-primary-700 flex items-center">
          <ChevronDown className="h-4 w-4 mr-1 rotate-90" />
          Back to Movies
        </Link>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        <div className="md:col-span-1">
          <img 
            src={movie.coverImageURL || 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwyfHxtb3ZpZSUyMHRoZWF0ZXIlMjBjaW5lbWF8ZW58MHx8fHwxNzQ3MDM2MzU2fDA&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800'} 
            alt={movie.title}
            className="w-full h-auto rounded-lg shadow-lg"
          />
        </div>
        
        <div className="md:col-span-2">
          <h1 className="text-3xl font-bold mb-4">{movie.title}</h1>
          
          <div className="flex flex-wrap items-center text-sm text-gray-600 dark:text-gray-400 mb-6 gap-x-6 gap-y-2">
            <div className="flex items-center">
              <Star className="h-4 w-4 text-yellow-500 mr-1" />
              <span>{movie.rating}/10</span>
            </div>
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-1" />
              <span>{movie.duration}</span>
            </div>
            <div className="flex items-center">
              <Calendar className="h-4 w-4 mr-1" />
              <span>{new Date(movie.releaseDate).toLocaleDateString()}</span>
            </div>
            <div className="flex items-center">
              <Globe className="h-4 w-4 mr-1" />
              <span>{movie.language}</span>
            </div>
          </div>
          
          <div className="mb-6">
            <div className="flex flex-wrap gap-2 mb-4">
              {movie.genre && movie.genre.map(genre => (
                <span 
                  key={genre} 
                  className="bg-gray-100 dark:bg-dark-700 px-3 py-1 rounded-full text-sm"
                >
                  {genre}
                </span>
              ))}
            </div>
            
            <p className="text-gray-700 dark:text-gray-300 mb-6">
              {movie.description}
            </p>
          </div>
          
          {!isBookingComplete && (
            <>
              <h3 className="text-xl font-semibold mb-4">Book Tickets</h3>
              
              <div className="mb-6">
                <h4 className="font-medium mb-2">Date</h4>
                <div className="flex flex-wrap gap-2">
                  {dates.map(date => {
                    const formattedDate = new Date(date).toLocaleDateString('en-US', {
                      weekday: 'short',
                      month: 'short',
                      day: 'numeric'
                    });
                    
                    return (
                      <button
                        key={date}
                        onClick={() => handleDateSelect(date)}
                        className={`px-4 py-2 border rounded-md ${
                          selectedDate === date 
                            ? 'bg-primary-600 text-white border-primary-600' 
                            : 'border-gray-300 hover:border-primary-600 dark:border-gray-600'
                        }`}
                      >
                        {formattedDate}
                      </button>
                    );
                  })}
                </div>
              </div>
              
              {selectedDate && (
                <div className="mb-6">
                  <h4 className="font-medium mb-2">Time</h4>
                  <div className="flex flex-wrap gap-2">
                    {times.map(time => (
                      <button
                        key={time}
                        onClick={() => handleTimeSelect(time)}
                        className={`px-4 py-2 border rounded-md ${
                          selectedTime === time 
                            ? 'bg-primary-600 text-white border-primary-600' 
                            : 'border-gray-300 hover:border-primary-600 dark:border-gray-600'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              
              {selectedDate && selectedTime && (
                <div className="mb-6">
                  <h4 className="font-medium mb-2">Theatre</h4>
                  <div className="space-y-2">
                    {theatres.map(theatre => (
                      <button
                        key={theatre.id}
                        onClick={() => handleTheatreSelect(theatre)}
                        className={`w-full px-4 py-3 border rounded-md flex justify-between items-center ${
                          selectedTheatre && selectedTheatre.id === theatre.id 
                            ? 'bg-primary-600 text-white border-primary-600' 
                            : 'border-gray-300 hover:border-primary-600 dark:border-gray-600'
                        }`}
                      >
                        <span>{theatre.name}</span>
                        <span>${theatre.price.toFixed(2)}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
              
              {selectedDate && selectedTime && selectedTheatre && !showSeatSelector && (
                <button 
                  onClick={handleShowSeatSelector}
                  className="btn btn-primary flex items-center"
                >
                  <Users className="h-5 w-5 mr-2" />
                  Select Seats
                </button>
              )}
            </>
          )}
          
          {isBookingComplete && (
            <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-green-800 dark:text-green-400 mb-4">Booking Successful!</h3>
              <p className="mb-4">Your tickets for <strong>{movie.title}</strong> have been confirmed.</p>
              
              <div className="space-y-2 mb-6">
                <p><span className="font-medium">Theatre:</span> {selectedTheatre.name}</p>
                <p><span className="font-medium">Date:</span> {new Date(selectedDate).toLocaleDateString()}</p>
                <p><span className="font-medium">Time:</span> {selectedTime}</p>
                <p><span className="font-medium">Seats:</span> {selectedSeats.join(', ')}</p>
              </div>
              
              <Link to="/movies" className="btn btn-primary">
                Browse More Movies
              </Link>
            </div>
          )}
        </div>
      </div>
      
      {showSeatSelector && !isBookingComplete && (
        <div className="card">
          <div className="p-6 border-b dark:border-gray-700">
            <h3 className="text-xl font-semibold">Select Your Seats</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Click on the seats you want to book at {selectedTheatre.name}
            </p>
          </div>
          
          <SeatSelector 
            availableSeats={availableSeats} 
            onSelectSeats={handleSelectSeats}
          />
        </div>
      )}
      
      {selectedSeats.length > 0 && !isBookingComplete && (
        <div className="mt-8">
          <div className="card p-6">
            <h3 className="text-xl font-semibold mb-4">Booking Summary</h3>
            
            <div className="space-y-4 mb-6">
              <div className="flex justify-between">
                <span>Movie:</span>
                <span className="font-medium">{movie.title}</span>
              </div>
              <div className="flex justify-between">
                <span>Theatre:</span>
                <span>{selectedTheatre.name}</span>
              </div>
              <div className="flex justify-between">
                <span>Date:</span>
                <span>{new Date(selectedDate).toLocaleDateString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Time:</span>
                <span>{selectedTime}</span>
              </div>
              <div className="flex justify-between">
                <span>Seats:</span>
                <span>{selectedSeats.join(', ')}</span>
              </div>
              <div className="flex justify-between">
                <span>Number of Tickets:</span>
                <span>{selectedSeats.length}</span>
              </div>
              <div className="flex justify-between">
                <span>Price per Ticket:</span>
                <span>${selectedTheatre.price.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold">
                <span>Total:</span>
                <span>${(selectedSeats.length * selectedTheatre.price).toFixed(2)}</span>
              </div>
            </div>
            
            <button 
              onClick={() => setIsBookingComplete(true)}
              className="btn btn-primary w-full flex items-center justify-center"
            >
              <CreditCard className="h-5 w-5 mr-2" />
              Complete Booking
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// Mock data for preview
const mockMovies = [
  {
    _id: '1',
    title: 'The Dark Knight',
    description: 'When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.',
    genre: ['Action', 'Crime', 'Drama'],
    duration: '152 min',
    language: 'English',
    releaseDate: '2008-07-18',
    coverImageURL: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwyfHxtb3ZpZSUyMHRoZWF0ZXIlMjBjaW5lbWF8ZW58MHx8fHwxNzQ3MDM2MzU2fDA&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800',
    rating: 9.0,
  },
  {
    _id: '2',
    title: 'Inception',
    description: 'A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.',
    genre: ['Action', 'Adventure', 'Sci-Fi'],
    duration: '148 min',
    language: 'English',
    releaseDate: '2010-07-16',
    coverImageURL: 'https://images.unsplash.com/photo-1526041092449-209d556f7a32?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwzfHxtb3ZpZSUyMHRoZWF0ZXIlMjBjaW5lbWF8ZW58MHx8fHwxNzQ3MDM2MzU2fDA&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800',
    rating: 8.8,
  },
  {
    _id: '3',
    title: 'Interstellar',
    description: 'A team of explorers travel through a wormhole in space in an attempt to ensure humanity\'s survival.',
    genre: ['Adventure', 'Drama', 'Sci-Fi'],
    duration: '169 min',
    language: 'English',
    releaseDate: '2014-11-07',
    coverImageURL: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxtb3ZpZSUyMHRoZWF0ZXIlMjBjaW5lbWF8ZW58MHx8fHwxNzQ3MDM2MzU2fDA&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800',
    rating: 8.6,
  }
];

export default MovieDetailPage;
 