import  HeroSection from '../components/HeroSection';
import FeaturedMovies from '../components/FeaturedMovies';
import FeaturedTheatres from '../components/FeaturedTheatres';

const HomePage = () => {
  return (
    <div>
      <HeroSection />
      <FeaturedMovies />
      <FeaturedTheatres />
      
      <div className="bg-white dark:bg-dark-800 py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-center">How It Works</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="h-16 w-16 bg-primary-100 dark:bg-primary-900/30 text-primary-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Browse Movies</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Explore our collection of latest movies and find what you're looking for.
              </p>
            </div>
            
            <div className="text-center">
              <div className="h-16 w-16 bg-primary-100 dark:bg-primary-900/30 text-primary-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Select Seats</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Choose your preferred theatre, date, time, and select the best seats.
              </p>
            </div>
            
            <div className="text-center">
              <div className="h-16 w-16 bg-primary-100 dark:bg-primary-900/30 text-primary-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Enjoy the Show</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Make your payment and receive your tickets instantly. Head to the theatre and enjoy!
              </p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-primary-600 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-3">Download Our Mobile App</h2>
          <p className="text-primary-100 mb-8 max-w-xl mx-auto">
            Get exclusive offers and book tickets on the go with our mobile application.
            Available for iOS and Android.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <button className="btn bg-white text-primary-600 hover:bg-primary-50">
              Download for iOS
            </button>
            <button className="btn bg-white text-primary-600 hover:bg-primary-50">
              Download for Android
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
 