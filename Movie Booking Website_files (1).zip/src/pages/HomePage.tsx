import  HeroSection from '../components/HeroSection';
import FeaturedMovies from '../components/FeaturedMovies';
import { Calendar, Clock, Users } from 'lucide-react';

const HomePage = () => {
  return (
    <div>
      <HeroSection />
      <FeaturedMovies />
      
      <div className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold mb-12 text-center">How It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="card p-6 text-center">
            <div className="flex justify-center mb-6">
              <div className="h-16 w-16 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center">
                <Calendar className="h-8 w-8 text-primary-600" />
              </div>
            </div>
            <h3 className="text-xl font-semibold mb-3">Browse Movies</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Explore our extensive collection of the latest films and upcoming releases. Filter by genre, rating, or release date.
            </p>
          </div>
          <div className="card p-6 text-center">
            <div className="flex justify-center mb-6">
              <div className="h-16 w-16 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center">
                <Clock className="h-8 w-8 text-primary-600" />
              </div>
            </div>
            <h3 className="text-xl font-semibold mb-3">Select Showtime</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Choose the perfect showtime from multiple options. Morning, afternoon, or evening - find what works for you.
            </p>
          </div>
          <div className="card p-6 text-center">
            <div className="flex justify-center mb-6">
              <div className="h-16 w-16 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center">
                <Users className="h-8 w-8 text-primary-600" />
              </div>
            </div>
            <h3 className="text-xl font-semibold mb-3">Book Seats</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Reserve your preferred seats in advance. Skip the lines and ensure you get the best spot in the theater.
            </p>
          </div>
        </div>
      </div>
      
      <div className="bg-gray-50 dark:bg-dark-800 py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Experience Comfort & Luxury</h2>
              <p className="text-lg text-gray-600 dark:text-gray-400 mb-6">
                Our theaters are equipped with state-of-the-art sound systems, comfortable seating, and crystal-clear projection. We provide the ultimate movie-watching experience.
              </p>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <div className="bg-primary-100 dark:bg-primary-900/30 p-1 rounded-full mr-3 mt-1">
                    <svg className="h-4 w-4 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                  </div>
                  <span>Premium recliner seats with extra legroom</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-primary-100 dark:bg-primary-900/30 p-1 rounded-full mr-3 mt-1">
                    <svg className="h-4 w-4 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                  </div>
                  <span>Dolby Atmos surround sound</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-primary-100 dark:bg-primary-900/30 p-1 rounded-full mr-3 mt-1">
                    <svg className="h-4 w-4 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                  </div>
                  <span>4K laser projection technology</span>
                </li>
              </ul>
            </div>
            <div>
              <img 
                src="https://images.unsplash.com/photo-1526041092449-209d556f7a32?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwzfHxjaW5lbWElMjBtb3ZpZSUyMHRoZWF0ZXJ8ZW58MHx8fHwxNzQ3MDMzODA5fDA&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800" 
                alt="Luxury cinema seating" 
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
 