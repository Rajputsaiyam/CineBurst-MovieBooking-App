import  { useState, useEffect } from 'react';
import TheatreCard from '../components/TheatreCard';
import { Filter, ChevronLeft, ChevronRight, MapPin } from 'lucide-react';

const TheatresPage = () => {
  const [theatres, setTheatres] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [selectedCity, setSelectedCity] = useState('');
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  const cities = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix'];

  useEffect(() => {
    const fetchTheatres = async () => {
      try {
        setLoading(true);
        // Instead of calling API directly, use mock data for now
        setTheatres(mockTheatres);
        setTotalPages(1);
        setLoading(false);
      } catch (err) {
        setTheatres(mockTheatres);
        setTotalPages(1);
        setError('Failed to fetch theatres');
        console.error('Error fetching theatres:', err instanceof Error ? err.message : String(err));
        setLoading(false);
      }
    };

    fetchTheatres();
  }, [currentPage]);

  const filteredTheatres = selectedCity
    ? theatres.filter(theatre => theatre.city === selectedCity)
    : theatres;

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="flex justify-center items-center h-60">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }

  if (error && theatres.length === 0) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="flex justify-center items-center h-60">
          <p className="text-red-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8">Theatres</h1>
      
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
        <div className="md:flex items-center space-y-4 md:space-y-0 md:space-x-4 mb-4 md:mb-0">
          <button 
            onClick={() => setIsFilterOpen(!isFilterOpen)}
            className="btn btn-outline flex items-center"
          >
            <Filter className="h-4 w-4 mr-2" />
            Filter by City
          </button>
          
          {isFilterOpen && (
            <div className="flex flex-wrap gap-2 mt-4 md:mt-0">
              <button
                onClick={() => setSelectedCity('')}
                className={`px-3 py-1 text-sm rounded-full ${
                  selectedCity === '' 
                    ? 'bg-primary-600 text-white' 
                    : 'bg-gray-100 text-gray-800 hover:bg-gray-200 dark:bg-dark-700 dark:text-gray-200 dark:hover:bg-dark-600'
                }`}
              >
                All Cities
              </button>
              {cities.map(city => (
                <button
                  key={city}
                  onClick={() => setSelectedCity(city)}
                  className={`px-3 py-1 text-sm rounded-full ${
                    selectedCity === city 
                      ? 'bg-primary-600 text-white' 
                      : 'bg-gray-100 text-gray-800 hover:bg-gray-200 dark:bg-dark-700 dark:text-gray-200 dark:hover:bg-dark-600'
                  }`}
                >
                  {city}
                </button>
              ))}
            </div>
          )}
        </div>
        
        <div className="flex items-center space-x-2">
          <button 
            onClick={handlePreviousPage}
            disabled={currentPage === 1}
            className={`p-2 rounded-full ${
              currentPage === 1 
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed dark:bg-dark-800 dark:text-gray-600' 
                : 'bg-gray-100 hover:bg-gray-200 dark:bg-dark-800 dark:hover:bg-dark-700'
            }`}
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          <span className="text-sm">
            Page {currentPage} of {totalPages}
          </span>
          <button 
            onClick={handleNextPage}
            disabled={currentPage === totalPages}
            className={`p-2 rounded-full ${
              currentPage === totalPages 
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed dark:bg-dark-800 dark:text-gray-600' 
                : 'bg-gray-100 hover:bg-gray-200 dark:bg-dark-800 dark:hover:bg-dark-700'
            }`}
          >
            <ChevronRight className="h-6 w-6" />
          </button>
        </div>
      </div>
      
      {filteredTheatres.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTheatres.map((theatre) => (
            <TheatreCard key={theatre._id} theatre={theatre} />
          ))}
        </div>
      ) : (
        <div className="flex justify-center items-center h-60">
          <p className="text-gray-500 dark:text-gray-400">
            No theatres found matching your criteria
          </p>
        </div>
      )}
      
      <div className="mt-12">
        <div className="card p-6">
          <h2 className="text-xl font-bold mb-4 flex items-center">
            <MapPin className="h-5 w-5 mr-2 text-primary-600" />
            Find Theatres Near You
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            Share your location to find theatres closest to you and get personalized recommendations.
          </p>
          <button className="btn btn-primary">
            Share Location
          </button>
        </div>
      </div>
    </div>
  );
};

// Mock data for preview
const mockTheatres = [
  {
    _id: '1',
    name: 'Grand Cineplex',
    plot: '123',
    street: 'Main Street',
    city: 'New York',
    country: 'USA',
    pincode: 10001,
    lat: '40.7128',
    lon: '-74.0060',
  },
  {
    _id: '2',
    name: 'Stellar Multiplex',
    plot: '456',
    street: 'Broadway Avenue',
    city: 'Los Angeles',
    country: 'USA',
    pincode: 90001,
    lat: '34.0522',
    lon: '-118.2437',
  },
  {
    _id: '3',
    name: 'Royal Cinema',
    plot: '789',
    street: 'Oak Street',
    city: 'Chicago',
    country: 'USA',
    pincode: 60007,
    lat: '41.8781',
    lon: '-87.6298',
  },
  {
    _id: '4',
    name: 'City Screens',
    plot: '101',
    street: 'Pine Avenue',
    city: 'New York',
    country: 'USA',
    pincode: 10002,
    lat: '40.7282',
    lon: '-73.9942',
  },
  {
    _id: '5',
    name: 'Diamond Theatres',
    plot: '202',
    street: 'Maple Road',
    city: 'Houston',
    country: 'USA',
    pincode: 77001,
    lat: '29.7604',
    lon: '-95.3698',
  },
  {
    _id: '6',
    name: 'Plaza Cinemas',
    plot: '303',
    street: 'Sunset Boulevard',
    city: 'Los Angeles',
    country: 'USA',
    pincode: 90002,
    lat: '34.0522',
    lon: '-118.2437',
  },
];

export default TheatresPage;
 